# Roadmap
- [ ] CampusBite app: menu, basket, orders, admin (orders/menu/inventory/reports)
- [ ] Oracle SQL Developer script
- [ ] More drinks/beverages on the menu

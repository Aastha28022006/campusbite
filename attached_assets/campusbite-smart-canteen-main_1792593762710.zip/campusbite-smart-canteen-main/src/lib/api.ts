import { supabase } from "@/integrations/supabase/client";
import type { MenuItem } from "./cart";

const rpc = supabase.rpc.bind(supabase) as unknown as (fn: string, args?: Record<string, unknown>) => Promise<{ data: any; error: { message: string } | null }>;

async function call<T>(fn: string, args?: Record<string, unknown>): Promise<T> {
  const { data, error } = await rpc(fn, args);
  if (error) throw new Error(error.message);
  return data as T;
}

export async function fetchMenu(): Promise<MenuItem[]> {
  const { data, error } = await supabase.from("menu_items").select("*").order("id");
  if (error) throw new Error(error.message);
  return (data ?? []).map((m: any) => ({ ...m, price: Number(m.price), rating: Number(m.rating) }));
}
export const placeOrder = (p: { name: string; roll: string; type: string; items: { id: number; qty: number }[] }) =>
  call<{ order_id: number; total: number }>("place_order", { p_name: p.name, p_roll: p.roll, p_type: p.type, p_items: p.items });
export const getMyOrders = (ids: number[]) => call<any[]>("get_orders_by_ids", { p_ids: ids });
export const adminDashboard = (pin: string) => call<any>("admin_dashboard", { p_pin: pin });
export const adminUpdateStatus = (pin: string, id: number, status: string) =>
  call<void>("admin_update_status", { p_pin: pin, p_order_id: id, p_status: status });
export const adminUpsertItem = (pin: string, i: Partial<MenuItem>) =>
  call<void>("admin_upsert_item", {
    p_pin: pin, p_id: i.id ?? null, p_name: i.name, p_desc: i.description ?? "", p_category: i.category,
    p_price: i.price, p_image: i.image_key ?? "burger", p_available: i.available ?? true,
  });
export const adminRestock = (pin: string, id: number, qty: number) =>
  call<void>("admin_restock", { p_pin: pin, p_ingredient_id: id, p_quantity: qty });

import burger from "@/assets/burger.jpg";
import noodles from "@/assets/noodles.jpg";
import manchurian from "@/assets/manchurian.jpg";
import friedrice from "@/assets/friedrice.jpg";
import momos from "@/assets/momos.jpg";
import pizza from "@/assets/pizza.jpg";
import thali from "@/assets/thali.jpg";
import coffee from "@/assets/coffee.jpg";
import gulabjamun from "@/assets/gulabjamun.jpg";
import chai from "@/assets/chai.jpg";
import lassi from "@/assets/lassi.jpg";
import limesoda from "@/assets/limesoda.jpg";
import shake from "@/assets/shake.jpg";

export const foodImages: Record<string, string> = {
  burger, noodles, manchurian, friedrice, momos, pizza, thali, coffee, gulabjamun, chai, lassi, limesoda, shake,
};
export const imageFor = (key: string) => foodImages[key] ?? burger;
export const heroBurger = burger;
export const CATEGORIES = [
  { name: "All", emoji: "" },
  { name: "Indian", emoji: "🍛" },
  { name: "Chinese", emoji: "🥢" },
  { name: "Fast Food", emoji: "🍔" },
  { name: "Pizza", emoji: "🍕" },
  { name: "Drinks", emoji: "🥤" },
  { name: "Desserts", emoji: "🍰" },
];
export const GST_RATE = 0.05;
export const inr = (n: number) => `₹${Number(n).toFixed(Number(n) % 1 ? 2 : 0)}`;

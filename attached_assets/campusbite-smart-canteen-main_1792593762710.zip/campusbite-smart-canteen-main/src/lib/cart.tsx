import { createContext, useContext, useEffect, useState, type ReactNode } from "react";
import { GST_RATE } from "./images";

export type MenuItem = {
  id: number; name: string; description: string; category: string;
  price: number; image_key: string; rating: number; available: boolean;
};
export type CartLine = { item: MenuItem; qty: number };
export type OrderType = "Dine In" | "Pick Up" | "Delivery";

export function billFor(lines: { price: number; qty: number }[]) {
  const subtotal = lines.reduce((s, l) => s + l.price * l.qty, 0);
  const tax = Math.round(subtotal * GST_RATE * 100) / 100;
  return { subtotal, tax, total: Math.round((subtotal + tax) * 100) / 100 };
}

type Ctx = {
  lines: CartLine[]; add: (i: MenuItem) => void; setQty: (id: number, q: number) => void; clear: () => void;
  orderType: OrderType; setOrderType: (t: OrderType) => void;
  favs: number[]; toggleFav: (id: number) => void;
  myOrders: number[]; addMyOrder: (id: number) => void;
};
const CartContext = createContext<Ctx | null>(null);

export function CartProvider({ children }: { children: ReactNode }) {
  const [lines, setLines] = useState<CartLine[]>([]);
  const [orderType, setOrderType] = useState<OrderType>("Dine In");
  const [favs, setFavs] = useState<number[]>([]);
  const [myOrders, setMyOrders] = useState<number[]>([]);
  const [loaded, setLoaded] = useState(false);

  useEffect(() => {
    try {
      setFavs(JSON.parse(localStorage.getItem("cb_favs") || "[]"));
      setMyOrders(JSON.parse(localStorage.getItem("cb_orders") || "[]"));
    } catch { /* ignore */ }
    setLoaded(true);
  }, []);
  useEffect(() => { if (loaded) localStorage.setItem("cb_favs", JSON.stringify(favs)); }, [favs, loaded]);
  useEffect(() => { if (loaded) localStorage.setItem("cb_orders", JSON.stringify(myOrders)); }, [myOrders, loaded]);

  const add = (item: MenuItem) => setLines((ls) => {
    const f = ls.find((l) => l.item.id === item.id);
    if (f) return ls.map((l) => (l.item.id === item.id ? { ...l, qty: Math.min(20, l.qty + 1) } : l));
    return [...ls, { item, qty: 1 }];
  });
  const setQty = (id: number, q: number) =>
    setLines((ls) => (q <= 0 ? ls.filter((l) => l.item.id !== id) : ls.map((l) => (l.item.id === id ? { ...l, qty: Math.min(20, q) } : l))));

  return (
    <CartContext.Provider value={{
      lines, add, setQty, clear: () => setLines([]), orderType, setOrderType,
      favs, toggleFav: (id) => setFavs((f) => (f.includes(id) ? f.filter((x) => x !== id) : [...f, id])),
      myOrders, addMyOrder: (id) => setMyOrders((o) => [id, ...o]),
    }}>
      {children}
    </CartContext.Provider>
  );
}
export function useCart() {
  const c = useContext(CartContext);
  if (!c) throw new Error("useCart outside provider");
  return c;
}

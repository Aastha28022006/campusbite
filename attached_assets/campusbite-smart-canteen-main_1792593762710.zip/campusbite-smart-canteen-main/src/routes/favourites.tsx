import { createFileRoute } from "@tanstack/react-router";
import { useSuspenseQuery } from "@tanstack/react-query";
import { AppShell } from "@/components/AppShell";
import { FoodCard } from "@/components/FoodCard";
import { useCart } from "@/lib/cart";
import { menuQuery } from "./index";

export const Route = createFileRoute("/favourites")({
  head: () => ({
    meta: [
      { title: "Favourites — CampusBite" },
      { name: "description", content: "Your favourite canteen dishes in one place." },
      { property: "og:title", content: "Favourites — CampusBite" },
      { property: "og:description", content: "Your favourite canteen dishes in one place." },
    ],
  }),
  loader: ({ context }) => context.queryClient.ensureQueryData(menuQuery),
  component: Favs,
});

function Favs() {
  const { data } = useSuspenseQuery(menuQuery);
  const { favs } = useCart();
  const items = data.filter((m) => favs.includes(m.id));
  return (
    <AppShell>
      <div className="mx-auto max-w-4xl">
        <h1 className="text-2xl font-semibold">Favourites</h1>
        {items.length === 0 ? <p className="mt-6 text-muted-foreground">Tap the ♡ on any dish to save it here.</p> : (
          <div className="mt-5 grid gap-4 sm:grid-cols-2 xl:grid-cols-3">{items.map((m) => <FoodCard key={m.id} item={m} />)}</div>
        )}
      </div>
    </AppShell>
  );
}

import { createFileRoute } from "@tanstack/react-router";
import { useQuery, useQueryClient } from "@tanstack/react-query";
import { useState } from "react";
import { toast } from "sonner";
import { AppShell } from "@/components/AppShell";
import { adminDashboard, adminRestock, adminUpdateStatus, adminUpsertItem } from "@/lib/api";
import { CATEGORIES, foodImages, inr } from "@/lib/images";

export const Route = createFileRoute("/admin")({
  head: () => ({
    meta: [
      { title: "Admin — CampusBite" },
      { name: "description", content: "Manage canteen orders, menu, inventory and sales reports." },
      { property: "og:title", content: "Admin — CampusBite" },
      { property: "og:description", content: "Manage canteen orders, menu, inventory and sales reports." },
    ],
  }),
  component: Admin,
});

const TABS = ["Orders", "Menu", "Inventory", "Reports"] as const;

function Admin() {
  const [pin, setPin] = useState("");
  const [ok, setOk] = useState("");
  const [tab, setTab] = useState<(typeof TABS)[number]>("Orders");
  const qc = useQueryClient();
  const { data, error } = useQuery({ queryKey: ["admin", ok], queryFn: () => adminDashboard(ok), enabled: !!ok, refetchInterval: 15000 });
  const refresh = () => qc.invalidateQueries();
  const act = async (fn: () => Promise<unknown>, msg: string) => {
    try { await fn(); toast.success(msg); refresh(); } catch (e) { toast.error((e as Error).message); }
  };

  if (!ok || error) {
    return (
      <AppShell showBasket={false}>
        <div className="mx-auto mt-20 max-w-sm rounded-2xl border bg-card p-6 shadow-card">
          <h1 className="text-xl font-semibold">Canteen admin</h1>
          <p className="mt-1 text-sm text-muted-foreground">Enter the admin PIN (demo: 1234)</p>
          {error && <p className="mt-2 text-sm text-destructive">{(error as Error).message}</p>}
          <input type="password" value={pin} onChange={(e) => setPin(e.target.value)} className="mt-4 w-full rounded-lg border px-3 py-2" />
          <button onClick={() => setOk(pin)} className="mt-3 w-full rounded-lg bg-primary py-2 font-semibold text-primary-foreground">Open dashboard</button>
        </div>
      </AppShell>
    );
  }

  return (
    <AppShell showBasket={false}>
      <div className="mx-auto max-w-5xl">
        <h1 className="text-2xl font-semibold">Admin dashboard</h1>
        <div className="mt-4 flex gap-2">
          {TABS.map((t) => (
            <button key={t} onClick={() => setTab(t)} className={`rounded-lg border px-4 py-1.5 text-sm ${tab === t ? "border-primary bg-primary text-primary-foreground" : "bg-card"}`}>{t}</button>
          ))}
        </div>
        {!data ? <p className="mt-6">Loading…</p> : (
          <div className="mt-6">
            {tab === "Orders" && (
              <div className="space-y-3">
                {data.orders.map((o: any) => (
                  <div key={o.id} className="flex flex-wrap items-center gap-4 rounded-xl border bg-card p-4">
                    <div className="flex-1">
                      <p className="font-semibold">#{o.id} · {o.customer} {o.roll_no && <span className="text-muted-foreground">({o.roll_no})</span>}</p>
                      <p className="text-xs text-muted-foreground">{o.items?.map((i: any) => `${i.qty}× ${i.name}`).join(", ")} · {o.order_type}</p>
                    </div>
                    <span className="font-semibold text-primary">{inr(o.total)}</span>
                    <select value={o.status} onChange={(e) => act(() => adminUpdateStatus(ok, o.id, e.target.value), `Order #${o.id} → ${e.target.value}`)} className="rounded-lg border px-2 py-1 text-sm">
                      {["Placed", "Preparing", "Ready", "Completed"].map((s) => <option key={s}>{s}</option>)}
                    </select>
                  </div>
                ))}
                {data.orders.length === 0 && <p className="text-muted-foreground">No orders yet.</p>}
                <h2 className="pt-6 font-semibold">Status change log</h2>
                <div className="rounded-xl border bg-card p-4 text-sm">
                  {data.log.map((l: any) => (
                    <p key={l.id} className="text-muted-foreground">{new Date(l.changed_at).toLocaleTimeString()} — Order #{l.order_id}: {l.old_status ?? "—"} → <b className="text-foreground">{l.new_status}</b></p>
                  ))}
                </div>
              </div>
            )}
            {tab === "Menu" && <MenuEditor items={data.menu} onSave={(i) => act(() => adminUpsertItem(ok, i), "Menu saved")} />}
            {tab === "Inventory" && (
              <div className="overflow-hidden rounded-xl border bg-card">
                {data.ingredients.map((i: any) => <InvRow key={i.id} i={i} onSave={(q) => act(() => adminRestock(ok, i.id, q), `${i.name} updated`)} />)}
              </div>
            )}
            {tab === "Reports" && (
              <div className="space-y-6">
                <div className="grid gap-4 sm:grid-cols-2">
                  <Stat label="Today's revenue" value={inr(Number(data.today.revenue))} />
                  <Stat label="Today's orders" value={String(data.today.orders)} />
                </div>
                <div className="rounded-xl border bg-card p-5">
                  <h3 className="font-semibold">Best-selling items</h3>
                  {data.best.map((b: any) => {
                    const max = Number(data.best[0]?.qty || 1);
                    return (
                      <div key={b.name} className="mt-3">
                        <div className="flex justify-between text-sm"><span>{b.name}</span><span>{b.qty} sold · {inr(Number(b.revenue))}</span></div>
                        <div className="mt-1 h-2 rounded-full bg-muted"><div className="h-2 rounded-full bg-primary" style={{ width: `${(Number(b.qty) / max) * 100}%` }} /></div>
                      </div>
                    );
                  })}
                  {data.best.length === 0 && <p className="mt-2 text-sm text-muted-foreground">No sales yet.</p>}
                </div>
                <div className="rounded-xl border bg-card p-5">
                  <h3 className="font-semibold">Last 7 days</h3>
                  {data.daily.map((d: any) => <p key={d.day} className="mt-2 flex justify-between text-sm"><span>{d.day}</span><span>{d.orders} orders · {inr(Number(d.revenue))}</span></p>)}
                </div>
              </div>
            )}
          </div>
        )}
      </div>
    </AppShell>
  );
}

function Stat({ label, value }: { label: string; value: string }) {
  return <div className="rounded-xl bg-hero p-5"><p className="text-sm text-muted-foreground">{label}</p><p className="text-3xl font-semibold text-primary">{value}</p></div>;
}

function InvRow({ i, onSave }: { i: any; onSave: (q: number) => void }) {
  const [q, setQ] = useState(String(i.quantity));
  const low = Number(i.quantity) <= Number(i.low_threshold);
  return (
    <div className="flex items-center gap-3 border-b p-3 last:border-0">
      <span className="flex-1 font-medium">{i.name}</span>
      {low && <span className="rounded-full bg-warning px-2 py-0.5 text-xs">Low stock</span>}
      <span className="w-28 text-sm text-muted-foreground">{Number(i.quantity)} {i.unit}</span>
      <input value={q} onChange={(e) => setQ(e.target.value)} type="number" className="w-24 rounded-lg border px-2 py-1 text-sm" />
      <button onClick={() => onSave(Number(q))} className="rounded-lg bg-primary px-3 py-1 text-sm text-primary-foreground">Set</button>
    </div>
  );
}

function MenuEditor({ items, onSave }: { items: any[]; onSave: (i: any) => void }) {
  const blank = { name: "", description: "", category: "Indian", price: 50, image_key: "burger", available: true };
  const [edit, setEdit] = useState<any>(blank);
  return (
    <div className="grid gap-6 md:grid-cols-[1fr_320px]">
      <div className="overflow-hidden rounded-xl border bg-card">
        {items.map((m) => (
          <div key={m.id} className="flex items-center gap-3 border-b p-3 last:border-0">
            <span className="flex-1">{m.name} <span className="text-xs text-muted-foreground">· {m.category}</span></span>
            <span className="text-sm">{inr(Number(m.price))}</span>
            <button onClick={() => onSave({ ...m, price: Number(m.price), available: !m.available })} className={`rounded-full px-2 py-0.5 text-xs ${m.available ? "bg-accent text-accent-foreground" : "bg-muted text-muted-foreground"}`}>{m.available ? "Available" : "Unavailable"}</button>
            <button onClick={() => setEdit({ ...m, price: Number(m.price) })} className="text-sm text-primary">Edit</button>
          </div>
        ))}
      </div>
      <div className="space-y-2 rounded-xl border bg-card p-4">
        <h3 className="font-semibold">{edit.id ? "Edit item" : "Add item"}</h3>
        <input value={edit.name} onChange={(e) => setEdit({ ...edit, name: e.target.value })} placeholder="Name" className="w-full rounded-lg border px-3 py-2 text-sm" />
        <input value={edit.description} onChange={(e) => setEdit({ ...edit, description: e.target.value })} placeholder="Description" className="w-full rounded-lg border px-3 py-2 text-sm" />
        <select value={edit.category} onChange={(e) => setEdit({ ...edit, category: e.target.value })} className="w-full rounded-lg border px-3 py-2 text-sm">
          {CATEGORIES.slice(1).map((c) => <option key={c.name}>{c.name}</option>)}
        </select>
        <select value={edit.image_key} onChange={(e) => setEdit({ ...edit, image_key: e.target.value })} className="w-full rounded-lg border px-3 py-2 text-sm">
          {Object.keys(foodImages).map((k) => <option key={k}>{k}</option>)}
        </select>
        <input type="number" value={edit.price} onChange={(e) => setEdit({ ...edit, price: Number(e.target.value) })} className="w-full rounded-lg border px-3 py-2 text-sm" />
        <button onClick={() => { if (!edit.name.trim()) { toast.error("Name required"); return; } onSave(edit); setEdit(blank); }} className="w-full rounded-lg bg-primary py-2 text-sm font-semibold text-primary-foreground">Save</button>
        {edit.id && <button onClick={() => setEdit(blank)} className="w-full text-sm text-muted-foreground">Cancel</button>}
      </div>
    </div>
  );
}

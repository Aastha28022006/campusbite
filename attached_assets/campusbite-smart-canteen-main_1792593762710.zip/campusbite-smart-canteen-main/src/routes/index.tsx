import { createFileRoute } from "@tanstack/react-router";
import { queryOptions, useSuspenseQuery } from "@tanstack/react-query";
import { Search } from "lucide-react";
import { useEffect, useState } from "react";
import { AppShell } from "@/components/AppShell";
import { FoodCard } from "@/components/FoodCard";
import { fetchMenu } from "@/lib/api";
import { CATEGORIES, heroBurger } from "@/lib/images";

export const menuQuery = queryOptions({ queryKey: ["menu"], queryFn: fetchMenu });

export const Route = createFileRoute("/")({
  head: () => ({
    meta: [
      { title: "CampusBite — College Canteen Menu" },
      { name: "description", content: "Browse vegetarian meals, add to cart and order from your college canteen." },
      { property: "og:title", content: "CampusBite — College Canteen Menu" },
      { property: "og:description", content: "Fresh veg meals, quick pickup and no waiting in line." },
    ],
  }),
  loader: ({ context }) => context.queryClient.ensureQueryData(menuQuery),
  component: Index,
});

function Index() {
  const { data: menu } = useSuspenseQuery(menuQuery);
  const [cat, setCat] = useState("All");
  const [q, setQ] = useState("");
  const [greet, setGreet] = useState("Hello");
  useEffect(() => {
    const h = new Date().getHours();
    setGreet(h < 12 ? "Good morning" : h < 17 ? "Good afternoon" : "Good evening");
  }, []);
  const items = menu.filter((m) => (cat === "All" || m.category === cat) &&
    (m.name + m.description).toLowerCase().includes(q.toLowerCase()));

  return (
    <AppShell>
      <div className="mx-auto max-w-4xl">
        <h1 className="text-xl font-semibold">{greet} 👋</h1>
        <section className="relative mt-4 flex items-center justify-between overflow-hidden rounded-3xl bg-hero p-7 sm:p-9">
          <div>
            <p className="text-[11px] font-medium tracking-[0.25em] text-muted-foreground">CAMPUS CANTEEN</p>
            <h2 className="mt-2 text-4xl font-semibold leading-tight sm:text-5xl">Find the food<br /><span className="text-primary">you love.</span></h2>
            <p className="mt-3 text-sm text-muted-foreground">Fresh meals, quick pickup and no waiting in line.</p>
          </div>
          <div className="relative hidden sm:block">
            <span className="absolute -top-2 left-0 z-10 rounded-full bg-card px-3 py-1 text-[11px] font-semibold text-primary shadow-card">🔥 Popular today</span>
            <img src={heroBurger} alt="Campus burger" width={816} height={816} className="h-44 w-48 rounded-[2rem] object-cover" />
          </div>
        </section>

        <label className="mt-5 flex items-center gap-3 rounded-xl border bg-card px-4 py-3">
          <Search className="h-4 w-4 text-muted-foreground" />
          <input value={q} onChange={(e) => setQ(e.target.value)} placeholder="Search noodles, pizza, chai, drinks…" className="w-full bg-transparent text-sm outline-none" />
        </label>

        <div className="mt-8 flex items-end justify-between">
          <div>
            <p className="text-[11px] tracking-[0.25em] text-muted-foreground">EXPLORE</p>
            <h2 className="text-xl font-semibold">Find the best food</h2>
          </div>
          <button onClick={() => { setCat("All"); setQ(""); }} className="text-sm font-semibold text-primary">View all →</button>
        </div>
        <div className="mt-4 flex flex-wrap gap-2">
          {CATEGORIES.map((c) => (
            <button key={c.name} onClick={() => setCat(c.name)}
              className={`rounded-lg border px-3.5 py-1.5 text-xs transition-colors ${cat === c.name ? "border-primary bg-primary text-primary-foreground" : "bg-card hover:bg-muted"}`}>
              {c.emoji} {c.name}
            </button>
          ))}
        </div>
        <div className="mt-5 grid gap-4 sm:grid-cols-2 xl:grid-cols-3">
          {items.map((m) => <FoodCard key={m.id} item={m} />)}
        </div>
        {items.length === 0 && <p className="mt-10 text-center text-muted-foreground">No dishes match your search.</p>}
      </div>
    </AppShell>
  );
}

import { createFileRoute } from "@tanstack/react-router";
import { useQuery } from "@tanstack/react-query";
import { Check } from "lucide-react";
import { AppShell } from "@/components/AppShell";
import { useCart } from "@/lib/cart";
import { getMyOrders } from "@/lib/api";
import { inr } from "@/lib/images";

export const Route = createFileRoute("/orders")({
  head: () => ({
    meta: [
      { title: "My Orders — CampusBite" },
      { name: "description", content: "Track your canteen orders from Placed to Ready." },
      { property: "og:title", content: "My Orders — CampusBite" },
      { property: "og:description", content: "Track your canteen orders from Placed to Ready." },
    ],
  }),
  component: Orders,
});

const STEPS = ["Placed", "Preparing", "Ready"];

function Orders() {
  const { myOrders } = useCart();
  const { data, isLoading } = useQuery({
    queryKey: ["my-orders", myOrders], queryFn: () => getMyOrders(myOrders),
    enabled: myOrders.length > 0, refetchInterval: 10000,
  });
  return (
    <AppShell>
      <div className="mx-auto max-w-3xl">
        <h1 className="text-2xl font-semibold">My orders</h1>
        {myOrders.length === 0 && <p className="mt-6 text-muted-foreground">You haven't placed any orders yet.</p>}
        {isLoading && <p className="mt-6 text-muted-foreground">Loading…</p>}
        <div className="mt-5 space-y-4">
          {data?.map((o) => {
            const idx = o.status === "Completed" ? 3 : STEPS.indexOf(o.status);
            return (
              <div key={o.id} className="rounded-2xl border bg-card p-5 shadow-card">
                <div className="flex justify-between">
                  <div>
                    <p className="text-lg font-semibold">Order #{o.id}</p>
                    <p className="text-xs text-muted-foreground">{new Date(o.created_at).toLocaleString()} · {o.order_type}</p>
                  </div>
                  <p className="text-lg font-semibold text-primary">{inr(o.total)}</p>
                </div>
                <p className="mt-2 text-sm text-muted-foreground">{o.items?.map((i: any) => `${i.qty}× ${i.name}`).join(", ")}</p>
                <div className="mt-5 flex items-center">
                  {STEPS.map((s, i) => (
                    <div key={s} className="flex flex-1 items-center last:flex-none">
                      <div className="flex flex-col items-center">
                        <div className={`grid h-8 w-8 place-items-center rounded-full text-xs ${i <= idx ? "bg-primary text-primary-foreground" : "bg-muted text-muted-foreground"}`}>
                          {i < idx || idx === 3 ? <Check className="h-4 w-4" /> : i + 1}
                        </div>
                        <span className="mt-1 text-xs">{s}</span>
                      </div>
                      {i < STEPS.length - 1 && <div className={`mx-2 mb-5 h-0.5 flex-1 ${i < idx ? "bg-primary" : "bg-muted"}`} />}
                    </div>
                  ))}
                </div>
              </div>
            );
          })}
        </div>
      </div>
    </AppShell>
  );
}

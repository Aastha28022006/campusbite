import { Heart, Star } from "lucide-react";
import { toast } from "sonner";
import { useCart, type MenuItem } from "@/lib/cart";
import { imageFor, inr } from "@/lib/images";

export function FoodCard({ item }: { item: MenuItem }) {
  const { add, favs, toggleFav } = useCart();
  const fav = favs.includes(item.id);
  return (
    <div className="flex flex-col rounded-2xl border bg-card p-2.5 shadow-card">
      <div className="relative overflow-hidden rounded-xl">
        <img src={imageFor(item.image_key)} alt={item.name} loading="lazy" width={944} height={704}
          className={`aspect-[2/1] w-full object-cover ${item.available ? "" : "grayscale"}`} />
        <button aria-label="Favourite" onClick={() => toggleFav(item.id)}
          className="absolute right-2 top-2 grid h-8 w-8 place-items-center rounded-full bg-card shadow-card">
          <Heart className={`h-4 w-4 ${fav ? "fill-destructive text-destructive" : "text-foreground"}`} />
        </button>
        {!item.available && <span className="absolute left-2 top-2 rounded-full bg-foreground px-2 py-0.5 text-xs text-background">Sold out</span>}
      </div>
      <div className="flex flex-1 flex-col px-1 pt-3">
        <h3 className="font-medium">{item.name}</h3>
        <p className="mt-1 text-xs text-muted-foreground">{item.description}</p>
        <div className="mt-auto flex items-end justify-between pt-4">
          <div>
            <p className="flex items-center gap-1 text-xs text-muted-foreground"><Star className="h-3 w-3 fill-star text-star" />{item.rating}</p>
            <p className="text-lg font-semibold text-primary">{inr(item.price)}</p>
          </div>
          <button disabled={!item.available}
            onClick={() => { add(item); toast.success(`${item.name} added`); }}
            className="rounded-lg bg-primary px-3 py-2 text-xs font-semibold text-primary-foreground hover:opacity-90 disabled:cursor-not-allowed disabled:bg-muted disabled:text-muted-foreground">
            {item.available ? "Add to cart" : "Unavailable"}
          </button>
        </div>
      </div>
    </div>
  );
}

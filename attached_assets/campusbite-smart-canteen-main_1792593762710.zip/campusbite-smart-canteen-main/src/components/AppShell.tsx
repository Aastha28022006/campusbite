import { Link, useRouterState } from "@tanstack/react-router";
import { Home, LayoutGrid, Clock, Heart, Settings, ShoppingBasket, Minus, Plus, Utensils } from "lucide-react";
import { useState, type ReactNode } from "react";
import { toast } from "sonner";
import { useQueryClient } from "@tanstack/react-query";
import { useCart, billFor, type OrderType } from "@/lib/cart";
import { imageFor, inr } from "@/lib/images";
import { placeOrder } from "@/lib/api";
import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog";

const nav = [
  { to: "/", icon: Home, label: "Menu" },
  { to: "/orders", icon: Clock, label: "My orders" },
  { to: "/favourites", icon: Heart, label: "Favourites" },
  { to: "/admin", icon: LayoutGrid, label: "Admin" },
] as const;

export function AppShell({ children, showBasket = true }: { children: ReactNode; showBasket?: boolean }) {
  const path = useRouterState({ select: (s) => s.location.pathname });
  return (
    <div className="flex min-h-screen w-full">
      <aside className="sticky top-0 hidden h-screen w-16 shrink-0 flex-col items-center gap-3 border-r bg-card py-6 sm:flex">
        <div className="mb-4 grid h-10 w-10 place-items-center rounded-xl bg-primary text-primary-foreground"><Utensils className="h-5 w-5" /></div>
        {nav.map((n) => {
          const active = path === n.to;
          return (
            <Link key={n.to} to={n.to} title={n.label}
              className={`grid h-10 w-10 place-items-center rounded-xl transition-colors ${active ? "bg-accent text-primary" : "text-muted-foreground hover:bg-muted"}`}>
              <n.icon className="h-5 w-5" />
            </Link>
          );
        })}
        <div className="mt-auto text-muted-foreground"><Settings className="h-5 w-5" /></div>
      </aside>
      <main className="min-w-0 flex-1 px-4 pb-24 pt-6 sm:px-8 lg:px-12">{children}</main>
      {showBasket && <Basket />}
      <nav className="fixed inset-x-0 bottom-0 z-20 flex justify-around border-t bg-card py-2 sm:hidden">
        {nav.map((n) => (
          <Link key={n.to} to={n.to} className={`flex flex-col items-center text-xs ${path === n.to ? "text-primary" : "text-muted-foreground"}`}>
            <n.icon className="h-5 w-5" />{n.label}
          </Link>
        ))}
      </nav>
    </div>
  );
}

function Basket() {
  const { lines, setQty, clear, orderType, setOrderType, addMyOrder } = useCart();
  const bill = billFor(lines.map((l) => ({ price: l.item.price, qty: l.qty })));
  const [name, setName] = useState("");
  const [roll, setRoll] = useState("");
  const [busy, setBusy] = useState(false);
  const [done, setDone] = useState<{ order_id: number; total: number } | null>(null);
  const qc = useQueryClient();

  const submit = async () => {
    if (!name.trim()) { toast.error("Please enter your name"); return; }
    setBusy(true);
    try {
      const r = await placeOrder({ name, roll, type: orderType, items: lines.map((l) => ({ id: l.item.id, qty: l.qty })) });
      addMyOrder(r.order_id);
      setDone(r);
      clear();
      qc.invalidateQueries();
    } catch (e) {
      toast.error((e as Error).message);
    } finally { setBusy(false); }
  };

  return (
    <aside className="sticky top-0 hidden h-screen w-80 shrink-0 flex-col border-l bg-card p-5 lg:flex">
      <div className="flex gap-2">
        {(["Dine In", "Pick Up", "Delivery"] as OrderType[]).map((t) => (
          <button key={t} onClick={() => setOrderType(t)}
            className={`rounded-lg border px-3 py-1.5 text-xs font-medium transition-colors ${orderType === t ? "border-primary bg-primary text-primary-foreground" : "bg-card text-foreground hover:bg-muted"}`}>{t}</button>
        ))}
      </div>
      {lines.length === 0 ? (
        <div className="mt-20 text-center text-sm text-muted-foreground">
          <ShoppingBasket className="mx-auto mb-3 h-6 w-6" />
          Your basket is empty.<br />Add something delicious!
        </div>
      ) : (
        <>
          <h3 className="mt-6 font-semibold">Your basket</h3>
          <div className="mt-3 flex-1 space-y-3 overflow-y-auto">
            {lines.map((l) => (
              <div key={l.item.id} className="flex items-center gap-3">
                <img src={imageFor(l.item.image_key)} alt={l.item.name} className="h-12 w-12 rounded-lg object-cover" />
                <div className="min-w-0 flex-1">
                  <p className="truncate text-sm font-medium">{l.item.name}</p>
                  <p className="text-xs text-primary">{inr(l.item.price * l.qty)}</p>
                </div>
                <div className="flex items-center gap-1.5">
                  <button aria-label="Decrease" onClick={() => setQty(l.item.id, l.qty - 1)} className="grid h-6 w-6 place-items-center rounded-md border hover:bg-muted"><Minus className="h-3 w-3" /></button>
                  <span className="w-5 text-center text-sm">{l.qty}</span>
                  <button aria-label="Increase" onClick={() => setQty(l.item.id, l.qty + 1)} className="grid h-6 w-6 place-items-center rounded-md border hover:bg-muted"><Plus className="h-3 w-3" /></button>
                </div>
              </div>
            ))}
          </div>
          <div className="space-y-2 border-t pt-4">
            <input value={name} onChange={(e) => setName(e.target.value)} placeholder="Your name" className="w-full rounded-lg border bg-background px-3 py-2 text-sm outline-none focus:border-primary" />
            <input value={roll} onChange={(e) => setRoll(e.target.value)} placeholder="Roll no. (optional)" className="w-full rounded-lg border bg-background px-3 py-2 text-sm outline-none focus:border-primary" />
            <Row label="Subtotal" value={inr(bill.subtotal)} />
            <Row label="GST (5%)" value={inr(bill.tax)} />
            <Row label="Total" value={inr(bill.total)} bold />
            <button disabled={busy} onClick={submit} className="mt-2 w-full rounded-lg bg-primary py-2.5 text-sm font-semibold text-primary-foreground hover:opacity-90 disabled:opacity-60">
              {busy ? "Placing…" : "Place order"}
            </button>
          </div>
        </>
      )}
      <Dialog open={!!done} onOpenChange={(o) => !o && setDone(null)}>
        <DialogContent>
          <DialogHeader><DialogTitle>Order placed! 🎉</DialogTitle></DialogHeader>
          <div className="text-center">
            <p className="text-sm text-muted-foreground">Your order number</p>
            <p className="text-5xl font-bold text-primary">#{done?.order_id}</p>
            <p className="mt-3">Total paid: <b>{done && inr(done.total)}</b></p>
            <Link to="/orders" onClick={() => setDone(null)} className="mt-5 inline-block rounded-lg bg-primary px-4 py-2 text-sm font-semibold text-primary-foreground">Track order</Link>
          </div>
        </DialogContent>
      </Dialog>
    </aside>
  );
}

function Row({ label, value, bold }: { label: string; value: string; bold?: boolean }) {
  return <div className={`flex justify-between text-sm ${bold ? "font-semibold" : "text-muted-foreground"}`}><span>{label}</span><span>{value}</span></div>;
}

CREATE TABLE public.customers (id uuid PRIMARY KEY DEFAULT gen_random_uuid(), name text NOT NULL, roll_no text, created_at timestamptz NOT NULL DEFAULT now());
CREATE TABLE public.menu_items (id serial PRIMARY KEY, name text NOT NULL, description text NOT NULL DEFAULT '', category text NOT NULL, price numeric(8,2) NOT NULL CHECK (price > 0), image_key text NOT NULL DEFAULT 'burger', rating numeric(2,1) NOT NULL DEFAULT 4.5, available boolean NOT NULL DEFAULT true);
CREATE TABLE public.ingredients (id serial PRIMARY KEY, name text NOT NULL UNIQUE, unit text NOT NULL DEFAULT 'units', quantity numeric(10,2) NOT NULL DEFAULT 0, low_threshold numeric(10,2) NOT NULL DEFAULT 10);
CREATE TABLE public.menu_item_ingredients (menu_item_id int REFERENCES public.menu_items(id) ON DELETE CASCADE, ingredient_id int REFERENCES public.ingredients(id) ON DELETE CASCADE, qty_per_item numeric(10,2) NOT NULL, PRIMARY KEY (menu_item_id, ingredient_id));
CREATE TABLE public.orders (id serial PRIMARY KEY, customer_id uuid REFERENCES public.customers(id), order_type text NOT NULL DEFAULT 'Dine In', status text NOT NULL DEFAULT 'Placed' CHECK (status IN ('Placed','Preparing','Ready','Completed')), subtotal numeric(10,2) NOT NULL DEFAULT 0, tax numeric(10,2) NOT NULL DEFAULT 0, total numeric(10,2) NOT NULL DEFAULT 0, created_at timestamptz NOT NULL DEFAULT now());
CREATE TABLE public.order_items (id serial PRIMARY KEY, order_id int REFERENCES public.orders(id) ON DELETE CASCADE, menu_item_id int REFERENCES public.menu_items(id), quantity int NOT NULL CHECK (quantity > 0), unit_price numeric(8,2) NOT NULL);
CREATE TABLE public.order_status_log (id serial PRIMARY KEY, order_id int REFERENCES public.orders(id) ON DELETE CASCADE, old_status text, new_status text NOT NULL, changed_at timestamptz NOT NULL DEFAULT now());

GRANT SELECT ON public.menu_items TO anon, authenticated;
GRANT ALL ON public.customers, public.menu_items, public.ingredients, public.menu_item_ingredients, public.orders, public.order_items, public.order_status_log TO service_role;
ALTER TABLE public.customers ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.menu_items ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.ingredients ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.menu_item_ingredients ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.orders ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.order_items ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.order_status_log ENABLE ROW LEVEL SECURITY;
CREATE POLICY "Public can view menu" ON public.menu_items FOR SELECT TO anon, authenticated USING (true);

-- Trigger: log status changes
CREATE OR REPLACE FUNCTION public.log_order_status() RETURNS trigger LANGUAGE plpgsql SECURITY DEFINER SET search_path = public AS $$
BEGIN
  IF TG_OP = 'INSERT' THEN
    INSERT INTO order_status_log(order_id, old_status, new_status) VALUES (NEW.id, NULL, NEW.status);
  ELSIF NEW.status IS DISTINCT FROM OLD.status THEN
    INSERT INTO order_status_log(order_id, old_status, new_status) VALUES (NEW.id, OLD.status, NEW.status);
  END IF;
  RETURN NEW;
END $$;
CREATE TRIGGER trg_order_status AFTER INSERT OR UPDATE OF status ON public.orders FOR EACH ROW EXECUTE FUNCTION public.log_order_status();

-- Function: calculate total
CREATE OR REPLACE FUNCTION public.calculate_order_total(p_order_id int) RETURNS numeric LANGUAGE sql STABLE SECURITY DEFINER SET search_path = public AS $$
  SELECT round(COALESCE(SUM(quantity * unit_price),0) * 1.05, 2) FROM order_items WHERE order_id = p_order_id
$$;

-- Procedure: place order (items = [{id, qty}])
CREATE OR REPLACE FUNCTION public.place_order(p_name text, p_roll text, p_type text, p_items jsonb) RETURNS jsonb LANGUAGE plpgsql SECURITY DEFINER SET search_path = public AS $$
DECLARE v_cust uuid; v_order int; v_item jsonb; v_mi menu_items%ROWTYPE; v_qty int; v_sub numeric := 0; r record;
BEGIN
  IF p_name IS NULL OR length(trim(p_name)) = 0 THEN RAISE EXCEPTION 'Please enter your name'; END IF;
  IF p_items IS NULL OR jsonb_array_length(p_items) = 0 THEN RAISE EXCEPTION 'Cart is empty'; END IF;
  IF p_type NOT IN ('Dine In','Pick Up','Delivery') THEN RAISE EXCEPTION 'Invalid order type'; END IF;
  INSERT INTO customers(name, roll_no) VALUES (trim(p_name), nullif(trim(p_roll),'')) RETURNING id INTO v_cust;
  INSERT INTO orders(customer_id, order_type) VALUES (v_cust, p_type) RETURNING id INTO v_order;
  FOR v_item IN SELECT * FROM jsonb_array_elements(p_items) LOOP
    v_qty := (v_item->>'qty')::int;
    IF v_qty IS NULL OR v_qty <= 0 OR v_qty > 20 THEN RAISE EXCEPTION 'Invalid quantity: %', v_item->>'qty'; END IF;
    SELECT * INTO v_mi FROM menu_items WHERE id = (v_item->>'id')::int;
    IF NOT FOUND THEN RAISE EXCEPTION 'Item does not exist'; END IF;
    IF NOT v_mi.available THEN RAISE EXCEPTION '% is currently unavailable', v_mi.name; END IF;
    FOR r IN SELECT mii.ingredient_id, mii.qty_per_item, i.name, i.quantity FROM menu_item_ingredients mii JOIN ingredients i ON i.id = mii.ingredient_id WHERE mii.menu_item_id = v_mi.id FOR UPDATE OF i LOOP
      IF r.quantity < r.qty_per_item * v_qty THEN RAISE EXCEPTION 'Not enough stock for % (% short of %)', v_mi.name, r.name, r.qty_per_item * v_qty - r.quantity; END IF;
      UPDATE ingredients SET quantity = quantity - r.qty_per_item * v_qty WHERE id = r.ingredient_id;
    END LOOP;
    INSERT INTO order_items(order_id, menu_item_id, quantity, unit_price) VALUES (v_order, v_mi.id, v_qty, v_mi.price);
    v_sub := v_sub + v_qty * v_mi.price;
  END LOOP;
  UPDATE orders SET subtotal = v_sub, tax = round(v_sub*0.05,2), total = calculate_order_total(v_order) WHERE id = v_order;
  RETURN jsonb_build_object('order_id', v_order, 'total', calculate_order_total(v_order));
END $$;

-- Customer: get orders by ids
CREATE OR REPLACE FUNCTION public.get_orders_by_ids(p_ids int[]) RETURNS jsonb LANGUAGE sql STABLE SECURITY DEFINER SET search_path = public AS $$
  SELECT COALESCE(jsonb_agg(o ORDER BY o.id DESC), '[]'::jsonb) FROM (
    SELECT ord.id, ord.status, ord.order_type, ord.total, ord.created_at, c.name AS customer,
      (SELECT jsonb_agg(jsonb_build_object('name', m.name, 'qty', oi.quantity, 'price', oi.unit_price)) FROM order_items oi JOIN menu_items m ON m.id = oi.menu_item_id WHERE oi.order_id = ord.id) AS items
    FROM orders ord LEFT JOIN customers c ON c.id = ord.customer_id WHERE ord.id = ANY(p_ids)) o
$$;

-- Admin
CREATE OR REPLACE FUNCTION public.check_admin(p_pin text) RETURNS void LANGUAGE plpgsql AS $$
BEGIN IF p_pin IS DISTINCT FROM '1234' THEN RAISE EXCEPTION 'Invalid admin PIN'; END IF; END $$;

CREATE OR REPLACE FUNCTION public.admin_dashboard(p_pin text) RETURNS jsonb LANGUAGE plpgsql STABLE SECURITY DEFINER SET search_path = public AS $$
BEGIN
  PERFORM check_admin(p_pin);
  RETURN jsonb_build_object(
    'orders', (SELECT COALESCE(jsonb_agg(o ORDER BY o.id DESC), '[]') FROM (
      SELECT ord.id, ord.status, ord.order_type, ord.total, ord.created_at, c.name AS customer, c.roll_no,
        (SELECT jsonb_agg(jsonb_build_object('name', m.name, 'qty', oi.quantity)) FROM order_items oi JOIN menu_items m ON m.id = oi.menu_item_id WHERE oi.order_id = ord.id) AS items
      FROM orders ord LEFT JOIN customers c ON c.id = ord.customer_id ORDER BY ord.id DESC LIMIT 100) o),
    'menu', (SELECT COALESCE(jsonb_agg(m ORDER BY m.id), '[]') FROM menu_items m),
    'ingredients', (SELECT COALESCE(jsonb_agg(i ORDER BY i.name), '[]') FROM ingredients i),
    'log', (SELECT COALESCE(jsonb_agg(l ORDER BY l.id DESC), '[]') FROM (SELECT * FROM order_status_log ORDER BY id DESC LIMIT 30) l),
    'today', (SELECT jsonb_build_object('revenue', COALESCE(SUM(total),0), 'orders', COUNT(*)) FROM orders WHERE created_at::date = now()::date),
    'daily', (SELECT COALESCE(jsonb_agg(d ORDER BY d.day), '[]') FROM (SELECT to_char(created_at::date,'DD Mon') AS day, created_at::date AS dt, SUM(total) AS revenue, COUNT(*) AS orders FROM orders WHERE created_at > now() - interval '7 days' GROUP BY created_at::date) d),
    'best', (SELECT COALESCE(jsonb_agg(b), '[]') FROM (SELECT m.name, SUM(oi.quantity) AS qty, SUM(oi.quantity*oi.unit_price) AS revenue FROM order_items oi JOIN menu_items m ON m.id = oi.menu_item_id GROUP BY m.name ORDER BY qty DESC LIMIT 6) b)
  );
END $$;

CREATE OR REPLACE FUNCTION public.admin_update_status(p_pin text, p_order_id int, p_status text) RETURNS void LANGUAGE plpgsql SECURITY DEFINER SET search_path = public AS $$
BEGIN PERFORM check_admin(p_pin); UPDATE orders SET status = p_status WHERE id = p_order_id; END $$;

CREATE OR REPLACE FUNCTION public.admin_upsert_item(p_pin text, p_id int, p_name text, p_desc text, p_category text, p_price numeric, p_image text, p_available boolean) RETURNS void LANGUAGE plpgsql SECURITY DEFINER SET search_path = public AS $$
BEGIN
  PERFORM check_admin(p_pin);
  IF p_price IS NULL OR p_price <= 0 THEN RAISE EXCEPTION 'Price must be positive'; END IF;
  IF p_id IS NULL THEN INSERT INTO menu_items(name, description, category, price, image_key, available) VALUES (p_name, p_desc, p_category, p_price, p_image, p_available);
  ELSE UPDATE menu_items SET name=p_name, description=p_desc, category=p_category, price=p_price, image_key=p_image, available=p_available WHERE id=p_id; END IF;
END $$;

CREATE OR REPLACE FUNCTION public.admin_restock(p_pin text, p_ingredient_id int, p_quantity numeric) RETURNS void LANGUAGE plpgsql SECURITY DEFINER SET search_path = public AS $$
BEGIN PERFORM check_admin(p_pin); IF p_quantity < 0 THEN RAISE EXCEPTION 'Quantity cannot be negative'; END IF; UPDATE ingredients SET quantity = p_quantity WHERE id = p_ingredient_id; END $$;

GRANT EXECUTE ON FUNCTION public.place_order(text,text,text,jsonb), public.get_orders_by_ids(int[]), public.admin_dashboard(text), public.admin_update_status(text,int,text), public.admin_upsert_item(text,int,text,text,text,numeric,text,boolean), public.admin_restock(text,int,numeric), public.calculate_order_total(int) TO anon, authenticated;

-- Seed
INSERT INTO menu_items(name, description, category, price, image_key, rating) VALUES
('Veg Hakka Noodles','Wok-tossed noodles with fresh vegetables','Chinese',110,'noodles',4.8),
('Veg Manchurian','Crispy veggie balls in tangy Indo-Chinese sauce','Chinese',95,'manchurian',4.7),
('Schezwan Fried Rice','Spicy fried rice with fresh vegetables','Chinese',105,'friedrice',4.6),
('Veg Momos','Steamed dumplings with spicy red chutney','Fast Food',80,'momos',4.9),
('Margherita Pizza','Cheesy pizza with basil and tomato','Pizza',160,'pizza',4.7),
('Campus Burger','Crispy patty, cheese and fresh vegetables','Fast Food',90,'burger',4.8),
('Paneer Thali','Paneer butter masala, dal, rice and naan','Indian',140,'thali',4.9),
('Cold Coffee','Chilled coffee topped with whipped cream','Drinks',60,'coffee',4.6),
('Gulab Jamun','Two warm jamuns soaked in rose syrup','Desserts',45,'gulabjamun',4.8);
INSERT INTO ingredients(name, unit, quantity, low_threshold) VALUES
('Noodles','packs',40,10),('Rice','kg',25,5),('Vegetables','kg',30,5),('Paneer','kg',8,2),('Flour','kg',20,5),('Cheese','kg',6,2),('Burger Buns','pcs',30,10),('Milk','L',15,4),('Coffee','g',800,200),('Khoya','kg',4,1);
INSERT INTO menu_item_ingredients VALUES
(1,1,1),(1,3,0.15),(2,3,0.2),(2,5,0.05),(3,2,0.2),(3,3,0.1),(4,5,0.1),(4,3,0.1),(5,5,0.2),(5,6,0.1),(6,7,1),(6,6,0.03),(6,3,0.05),(7,4,0.15),(7,2,0.15),(7,5,0.05),(8,8,0.25),(8,9,20),(9,10,0.08);
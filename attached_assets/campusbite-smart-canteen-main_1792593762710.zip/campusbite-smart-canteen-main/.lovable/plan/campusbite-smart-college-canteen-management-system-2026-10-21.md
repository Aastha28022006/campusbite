# CampusBite — Smart College Canteen Management System

A vegetarian canteen app styled like the sample: soft mint/teal theme, left icon rail, centre menu, right basket panel.

## Student side
- **Home / Menu** (`/`): greeting ("Good afternoon"), mint banner "Find the food *you love.*" with a burger photo and "Popular today" badge, search bar, category chips (All, Indian, Chinese, Fast Food, Pizza, Drinks, Desserts), food cards with photo, heart, name, description, rating, ₹ price, "Add to cart". Sold-out items show as unavailable.
- **Basket panel** (right): Dine In / Pick Up / Delivery toggle, line items with +/- quantity, subtotal, tax, total, "Place order". Empty state as in sample.
- **Order confirmation**: shows order number and total.
- **My Orders** (`/orders`): status tracker Placed → Preparing → Ready.
- **Favourites** (`/favourites`).

## Admin side (`/admin`, simple admin PIN)
- **Orders**: list, change status (status changes are logged with time).
- **Menu**: add/edit items, price, category, availability.
- **Inventory**: ingredient quantities; stock auto-deducts when an order is placed; low-stock warnings.
- **Reports**: today's revenue, order count, best-selling items chart.

## Rules
- Invalid quantities (0, negative, above stock) and unavailable items are rejected with a clear message.
- Bill = sum of items + 5% GST.

## Data storage
The live app stores data in Lovable Cloud (tables: customers, menu_items, orders, order_items, ingredients, recipe links, order_status_log) with an equivalent place-order routine, total function, status-log trigger and validation.

For your teacher demo, I will also produce a ready-to-run **Oracle SQL Developer script** (`campusbite_oracle.sql`) containing: the same tables + sample veg menu, `PLACE_ORDER` procedure, `CALCULATE_ORDER_TOTAL` function, status-log trigger, `CAMPUSBITE_PKG` package, custom exceptions for invalid quantity / unavailable item, and report queries.

(If you'd rather connect the app directly to your own Oracle Autonomous Database, tell me and I'll swap the storage to that instead.)

## Visuals
- 9 generated veg food photos (noodles, manchurian, fried rice, momos, pizza, burger, paneer thali, cold coffee, gulab jamun) + banner burger.
- Teal primary, mint gradients, rounded white cards, clean geometric font.

## Technical notes
- TanStack routes: index, orders, favourites, admin (orders/menu/inventory/reports tabs).
- Server functions for place order (validates + decrements stock atomically via a database function), status updates, reports.
- Cart in local state; demo seed data inserted via migration.
